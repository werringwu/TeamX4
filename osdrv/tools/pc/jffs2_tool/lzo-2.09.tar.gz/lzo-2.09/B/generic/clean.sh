#! /bin/sh
## vim:set ts=4 sw=4 et:
# Copyright (C) 1996-2015 Markus F.X.J. Oberhumer

rm -f *.o liblzo2.a dict.out lzopack.out precomp.out precomp2.out simple.out lzotest.out testmini.out

true
